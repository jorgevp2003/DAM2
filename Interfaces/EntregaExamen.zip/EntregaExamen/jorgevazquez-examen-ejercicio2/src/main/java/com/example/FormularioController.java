package com.example;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;

/**
 * 
 * FormularioController
 * @author Jorge Vazquez
 */
public class FormularioController {

    private final FormularioView vista;
    private final Stage stagePrincipal;

    public FormularioController(FormularioView vista, Stage stagePrincipal) {
        this.vista = vista;
        this.stagePrincipal = stagePrincipal;
        inicializarEventos();
    }

    /**
     * Inicializa los eventos de la vista.
     */
    private void inicializarEventos() {
        vista.getCbEstado().valueProperty().addListener((obs, anterior, nuevo) -> {
            Label lbl = vista.getLblEstadoSeleccionado();
            if (nuevo == null) {
                lbl.setText("Estado seleccionado: ninguno");
                lbl.setStyle("");
            } else {
                lbl.setText("Estado seleccionado: " + nuevo);
                lbl.setStyle("-fx-text-fill: " + vista.getCbEstado().getColor() + "; -fx-font-weight: bold;");
            }
        });

        vista.getBtnConsultar().setOnAction(e -> consultarIncidencia());
    }

    /**
     * Consulta la incidencia seleccionada y abre una ventana modal con el resumen.
     */
    private void consultarIncidencia() {
        String aula = vista.getCbAula().getValue();
        String equipamiento = vista.getCbEquipamiento().getValue();
        String estado = vista.getCbEstado().getEstado();

        if (aula == null || equipamiento == null || estado == null) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.initOwner(stagePrincipal);
            alert.setTitle("Faltan datos");
            alert.setHeaderText(null);
            alert.setContentText("Selecciona aula, equipamiento y estado de la incidencia.");
            alert.showAndWait();
            return;
        }

        abrirResumen(aula, equipamiento, estado);
    }

    /**
     * Abre una ventana modal con el resumen de la incidencia seleccionada.
     * @param aula
     * @param equipamiento
     * @param estado
     */
    private void abrirResumen(String aula, String equipamiento, String estado) {
        Stage resumen = new Stage();
        resumen.initOwner(stagePrincipal);
        resumen.initModality(Modality.WINDOW_MODAL);
        resumen.setTitle("Resumen incidencias");

        Label lblTitulo = new Label("Resumen incidencias");
        lblTitulo.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");

        Label lblAula = new Label("Aula: " + aula);
        Label lblEquipamiento = new Label("Equipamiento: " + equipamiento);
        Label lblEstado = new Label("Estado: " + estado);
        lblEstado.setStyle("-fx-text-fill: " + vista.getCbEstado().getColor() + "; -fx-font-weight: bold;");

        Button btnCerrar = new Button("Cerrar");
        btnCerrar.setCancelButton(true);
        btnCerrar.setOnAction(e -> resumen.close());

        VBox raiz = new VBox(10, lblTitulo, lblAula, lblEquipamiento, lblEstado, btnCerrar);
        raiz.setPadding(new Insets(20));
        raiz.setAlignment(Pos.CENTER_LEFT);

        resumen.setScene(new Scene(raiz, 320, 220));
        resumen.showAndWait();
    }
}
