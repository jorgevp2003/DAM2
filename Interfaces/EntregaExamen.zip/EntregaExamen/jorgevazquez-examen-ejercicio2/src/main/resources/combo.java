import javafx.scene.control.ComboBox;

public class combo extends ComboBox{
    private String estado;
    private String color;


    public combo() {
        super();
    }

    public String getEstado() {
        return estado;
    }
    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getColor() {
        return color;
    }
    public void setColor(String color) {
        this.color = color;
    }

    public boolean esEstadoFinalizado() {
        return "Finalizado".equals(estado);
    }
    public void reiniciar(){
    }
    
    public void actualizarColor(){
        StringBuilder style = new StringBuilder();
        if(getEstado()=="Resuelta"){
            style.append("-fx-background-color: green;");
        } else if(getEstado()=="Pendiente"){
            style.append("-fx-background-color: orange;");
        } else if(getEstado()=="En Proceso"){
            style.append("-fx-background-color: blue;");
        }
    }
    public void actualizarColor(String estado) {
        StringBuilder style = new StringBuilder();
        if (estado.equals("Resuelta")) {
            style.append("-fx-background-color: green;");
        } else if (estado.equals("Pendiente")) {
            style.append("-fx-background-color: orange;");
        } else if (estado.equals("En Proceso")) {
            style.append("-fx-background-color: blue;");
        }
        setStyle(style.toString());
    }
    public void actualizarColor(String estado, String color) {
        StringBuilder style = new StringBuilder();
        if (estado.equals("Resuelta")) {
            style.append("-fx-background-color: green;");
        } else if (estado.equals("Pendiente")) {
            style.append("-fx-background-color: orange;");
        } else if (estado.equals("En Proceso")) {
            style.append("-fx-background-color: blue;");
        }
        setStyle(style.toString());
    }
}